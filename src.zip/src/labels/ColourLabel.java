/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labels;

import java.util.ArrayList;

/**
 *
 * @author michaelgoode
 */
public class ColourLabel extends Label {

    
    
    public ColourLabel() {
        
    }

    public ColourLabel( String ref, String cat, String type, int order, String set, String boxQty ) {
        super(ref,cat,type,order,set,boxQty);
        
    }
    
    
  
}
