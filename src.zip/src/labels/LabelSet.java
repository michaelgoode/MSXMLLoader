/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labels;

import java.util.HashSet;

/**
 *
 * @author michaelgoode
 */
public class LabelSet extends HashSet {
    
    public LabelSet() {
        
    }
    
}
